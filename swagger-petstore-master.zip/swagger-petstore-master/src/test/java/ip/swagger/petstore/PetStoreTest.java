package ip.swagger.petstore;

public class PetStoreTest {

}
